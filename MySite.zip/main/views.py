from django.shortcuts import render
from django.http import HttpResponse
from .models import Post

def home_page(request):
    posts = Post.objects.all().order_by('-created_at')[:5]
    
    context = {
        'posts': posts,
        'title': 'Trang chủ MySite',
        'description': 'Chào mừng đến với website Django của bạn!',
        'total_posts': Post.objects.count()
    }
    return render(request, 'main/home.html', context)

def about_page(request):
    context = {
        'title': 'Giới thiệu',
        'description': 'Website được xây dựng bằng Django'
    }
    return render(request, 'main/about.html', context)
